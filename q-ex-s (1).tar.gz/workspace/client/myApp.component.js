angular.module("myApp").component('myApp', {
    templateUrl: "myApp.template.html",
    controller: myAppController
})

function myAppController($scope, nameService, canvasesService) {

    this.indexes = [];

    this.$onInit = function() {
        canvasesService.addCanvasesListener(this.getCanvases.bind(this));
    }

    this.getCanvases = function(canvases) {
        this.indexes = [];
        for (var key in canvases) {
            this.indexes.push(key);
        }
        $scope.$digest();
    }

    this.setName = function(name) {
        nameService.setName(name);
    }
}
