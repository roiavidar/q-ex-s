angular.module("myApp").service("nameService" , function() {
   var name = "";
   
   this.getName = function() {
       return name;
   }
   
   this.setName = function(newName) {
       name = newName;
   }
});