angular.module('myApp').service('canvasesService', function() {
    var canvases = {};
    var socket = io.connect();
    var canvasesListeners = [];
    var canvasPainetListeners = [];
    var canvasToResetListeners = [];
    var canvas = {};
    socket.on('connect', function(updatedCavases) {});

    socket.on('canvases', function(updatedCavases) {
        canvases = updatedCavases;
        this.triggerCanvasesListeners();
    }.bind(this));
    
    socket.on('canvasPaint', function(tempCanvas) {
        canvas = tempCanvas;
         this.triggerCanvasPaintListeners();
    }.bind(this));
    
    this.triggerCanvasPaintListeners = function() {
        canvasPainetListeners.forEach(function(listener) {
            listener(canvas);
        })
    }
    
    socket.on('resetPaint', function(canvasToReset) {
        canvasToResetListeners.forEach(function(listener) {
            listener(canvasToReset);
        })
    });
    
    this.addCanvasResetListener = function(listener) {
        canvasToResetListeners.push(listener)
    }
    
    this.addCanvasesListener = function(listener) {
        canvasesListeners.push(listener);
    }
    
    this.addCanvasPainetListener = function(listener) {
        canvasPainetListeners.push(listener);
    }

    this.triggerCanvasesListeners = function() {
        canvasesListeners.forEach(function(listener) {
            listener(canvases);
        })
    }
    
    this.startDrawing = function(data) {
        socket.emit("startDrawing", data);
    }
    
    this.drawing = function(data) {
        socket.emit("drawing", data);
    }
    
    this.clearDrawing = function(data) {
        socket.emit("clearDrawing", data);
    }
    
    this.getCanvas = function(canvasId) {
        return canvases[canvasId];
    }
});
