angular.module('myApp').component('drawingBoard', {
    templateUrl: "drawingBoard/drawingBoard.template.html",
    controller: drawingBoardController,
    bindings: {
        canvasid: "@"
    }
})

function drawingBoardController($scope, $timeout, nameService, canvasesService) {
    this.drawerName = "";
    this.nameService = nameService;
    this.canvasesService = canvasesService;
    this.first = true;

    this.$onInit = function() {
        // var canvasImages = JSON.parse(localStorage.getItem("canvasImages")) || {};
        // if(canvasImages[this.canvasid] !== undefined) {
        //     this.drawImage(canvasImages[this.canvasid]);
        // } else {
        //     this.drawImage(this.image);   
        // }


        var canvas = this.canvasesService.getCanvas(this.canvasid);
        var canvasObj = {};
        canvasObj[this.canvasid] = canvas
        this.canvasesListener(canvasObj);

        canvasesService.addCanvasesListener(this.canvasesListener.bind(this));
        canvasesService.addCanvasPainetListener(this.canvasPaintListener.bind(this));
        canvasesService.addCanvasResetListener(this.canvasPaintResetListener.bind(this));
    }

    this.canvasPaintResetListener = function(canvas) {
        if (canvas.id === this.canvasid) {
            this.image = canvas.image;
            this.inUse = false;
            this.clearBoard();
            this.drawImage(this.image);
            $scope.$digest();
        }
    };

    this.canvasPaintListener = function(canvas) {
        if (canvas.id === this.canvasid && canvas.drawerName !== this.nameService.getName()) {
            this.image = canvas.image;
            this.drawImage(this.image);
        }
    }

    this.canvasesListener = function(canvases) {
        var canvas = canvases[this.canvasid];
        this.image = canvas["image"];
        this.drawerName = canvas["drawerName"];
        if (this.drawerName === nameService.getName()) {
            this.inUse = false;
        }
        else {
            this.inUse = canvas["inUse"];
        }

        if (!$scope.$$phase && !this.first) {
            //$digest or $apply
            $scope.$digest();
        }

        if (this.first) {
            this.drawImage(this.image);
            this.first = false;
        }
    }

    this.drawImage = function(image) {
        var promise = new Promise(function(resolve, reject) {
            var img = new Image();
            img.onload = function() {
                this.ctx.drawImage(img, 0, 0);
                this.saveDrawing();
                resolve();
            }.bind(this);
            img.src = image;
        }.bind(this));

        return promise;
    }

    this.resetBoard = function() {
        this.clearBoard();
        this.drawImage(this.image).then(function() {
            canvasesService.clearDrawing({ canvasId: this.canvasid, userName: nameService.getName(), image: this.canvas.toDataURL() })
        }.bind(this));
    }

    this.clearBoard = function() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    this.saveDrawing = function() {
        var canvasImages = JSON.parse(localStorage.getItem("canvasImages")) || {};
        canvasImages[this.canvasid] = this.canvas.toDataURL();
        localStorage.setItem("canvasImages", JSON.stringify(canvasImages));
    }
}


angular.module('myApp').directive('canvasDir', function() {
    return {
        restrict: "A",
        link: function(scope, elements, attrs) {
            var ctrl = scope.$ctrl;
            var element = elements[0];
            ctrl.canvas = element;
            var isDown = false;
            var ctx = element.getContext("2d");
            ctrl.ctx = ctx;
            var canvasX, canvasY;
            ctx.lineWidth = 5;

            element.addEventListener('mousedown', function(e) {

                if (ctrl.nameService.getName() === "" || ctrl.inUse) {
                    return;
                }

                isDown = true;
                ctx.beginPath();
                canvasX = e.pageX - element.offsetLeft;
                canvasY = e.pageY - element.offsetTop;
                ctx.moveTo(canvasX, canvasY);

                ctrl.canvasesService.startDrawing({ canvasId: ctrl.canvasid, userName: ctrl.nameService.getName(), image: element.toDataURL() })
            })

            element.addEventListener('mousemove', function(e) {
                if (isDown != false) {
                    canvasX = e.pageX - element.offsetLeft;
                    canvasY = e.pageY - element.offsetTop;
                    ctx.lineTo(canvasX, canvasY);
                    ctx.strokeStyle = "blue";
                    ctx.stroke();

                    ctrl.canvasesService.drawing({ canvasId: ctrl.canvasid, userName: ctrl.nameService.getName(), image: element.toDataURL() })
                }

            })

            element.addEventListener('mouseup', function(e) {
                isDown = false;
                ctx.closePath();

                ctrl.saveDrawing();
            });
        }
    }
});
