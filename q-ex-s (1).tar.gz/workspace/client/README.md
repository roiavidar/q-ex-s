npm install - install angularjs and http-server

npm start - start http-server on localhost:8080